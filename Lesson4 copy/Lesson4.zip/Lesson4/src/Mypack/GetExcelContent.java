package Mypack;
import java.io.File;
import java.io.IOException;

import jxl.Workbook;
import jxl.write.WriteException;
import jxl.Sheet;
import jxl.Cell;
import jxl.read.biff.BiffException;

public class GetExcelContent 
{
	public static int RowCount(int a) throws BiffException, IOException, WriteException
	{
		int rowCount;
		Workbook workbook = Workbook.getWorkbook(new File("Checklist.xls"));
		Sheet sheet = workbook.getSheet(a);
		rowCount=sheet.getRows();
		return rowCount;
	}
	
	public static String GetQuery(int a, int b) throws BiffException, IOException, WriteException
	{
		Workbook workbook = Workbook.getWorkbook(new File("Checklist.xls"));
		Sheet sheet = workbook.getSheet(a);
		Cell cell1 = sheet.getCell(2, b);
		String query=cell1.getContents();
		return query;
	}
	
	public static String GetQueryDescription(int a, int b) throws BiffException, IOException, WriteException
	{
		Workbook workbook = Workbook.getWorkbook(new File("Checklist.xls"));
		Sheet sheet = workbook.getSheet(a);
		Cell cell1 = sheet.getCell(1, b);
		String description=cell1.getContents();
		return description;
	}
}
