package Mypack;

import java.sql.*;
import java.io.File;
import java.io.IOException;

import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.Pattern;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.read.biff.BiffException;
import jxl.write.WriteException;
import jxl.format.Border;
import jxl.format.BorderLineStyle;

public class Framework {
	public enum TestResult {
		PASS,
		FAIL,
		BLOCKED
	}
	private static Connection connection = null;
	private static Statement statement = null;
	  private static String username = "root";
	  private static String password = "1989";
	  private static String URL = "jdbc:mysql://localhost/test";
	  
	  private static void addCell(WritableSheet sheet, Border border, 
		      BorderLineStyle borderLineStyle, Colour colour, Pattern pattern,
		      int col, int row, String desc) throws WriteException {
		    
		    WritableFont cellFont = new WritableFont(WritableFont.TIMES, 10);
		    WritableCellFormat cellFormat = new WritableCellFormat(cellFont);
		    cellFormat.setBorder(border, borderLineStyle);
		    cellFormat.setBackground(colour, pattern);
		    Label label = new Label(col, row, desc, cellFormat);
		    sheet.addCell(label);
		  }

	  public static void main(String[] args) throws BiffException, IOException, WriteException,SQLException {
	    DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    //downloading driver
	    connection = DriverManager.getConnection(URL, username, password);
	    //connecting to DB
	    if(connection!=null) System.out.println(TestResult.PASS + "  Connection Successful\n");
	    if (connection==null) {
	    	System.out.print(TestResult.BLOCKED);
	    	System.exit(0);
	    }
	    statement = connection.createStatement(); 
	    
	    //creating header for resulting table
        WritableWorkbook workbook = Workbook.createWorkbook(new File("TC_result.xls"));
	    WritableSheet sheet = workbook.createSheet("TC Result", 0);
	    addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.WHITE, Pattern.SOLID,0, 0, "Number");
	    addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.WHITE, Pattern.SOLID,1, 0, "Test case name");
	    addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.WHITE, Pattern.SOLID,2, 0, "Result");
	    	    	    
	    //reading queries
	    int k=1;
	    int failNumber=0;
	    for (int i=0;i<3;i++)
	    {
	    	for (int j=1;j<GetExcelContent.RowCount(i);j++)
	    	{
	    		String myQuery;
	    	    myQuery =GetExcelContent.GetQuery(i,j);
	    	    String myScenario =GetExcelContent.GetQueryDescription(i,j);
	    	    ResultSet result = statement.executeQuery(myQuery);
	    	    
	    	    //null-check for rows
	    	    int size =0;
	    	    String str = Integer.toString(k);    	        	    
    	    	if (result != null) {
	    	        result.beforeFirst();
	    	        result.last();
	    	        size = result.getRow();
	    	    }
    	    	//Checking result of query
	    	    if (size==0) 
	    	    	{
	    	    	System.out.print("\n"+ k + myScenario + TestResult.FAIL);
	    	    	addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.WHITE, Pattern.SOLID,0, k, str);
	    			addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.WHITE, Pattern.SOLID,1, k, myScenario);
	    			addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.RED, Pattern.SOLID,2, k, "FAIL");
	    			failNumber++;
	    	    	}
	    	    else 
	    	    	{
	    	    	System.out.print("\n"+ k + myScenario+ TestResult.PASS);  	
	    	    	addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.WHITE, Pattern.SOLID,0, k, str);
	    			addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.WHITE, Pattern.SOLID,1, k, myScenario);
	    			addCell(sheet, Border.ALL, BorderLineStyle.MEDIUM, Colour.GREEN, Pattern.SOLID,2, k, "PASS");
	    	    	}
	    	    k++;
	    	    result.close();
	    	}
	    }   
	    if(failNumber>0) System.out.print("\n" +"Unfortunately your test build is red");  
	    else System.out.print("\n" +"Test case is passed"); 
	    //Close and free allocated memory */
	    workbook.write(); 
		workbook.close(); 
	    statement.close();
	    connection.close();
	  }
}
